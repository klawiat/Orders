﻿using Oreders.Domain.Entity;

namespace Orders.WebApi.Models.ViewModels
{
    public class RelationViewModel
    {
        public Guid Id { get; set; }
        public uint uty { get; set; }
    }
}
