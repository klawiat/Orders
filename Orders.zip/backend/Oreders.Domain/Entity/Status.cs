﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oreders.Domain.Entity
{
    public class Status
    {
        public uint Id { get; set; }
        public string Name { get; set; }
        public string DisplayName { get; set; }
        public List<Order> Order { get; set; }
    }
}
