﻿using Microsoft.EntityFrameworkCore;
using Oreders.Domain.Entity;
using Oreders.Domain.Enums;
using System.Security.Cryptography.X509Certificates;

namespace Oredrs.Infrastructure
{
    public class OrdersDbContext:DbContext
    {
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Oreders { get; set; }
        public DbSet<Relation> Relations { get; set; }
        public DbSet<Status> Statuses { get; set; }
        public OrdersDbContext(DbContextOptions options):base(options)
        {
            Database.EnsureCreated();
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            //Установка связей для таблицы реализующей связь многие ко многим
            modelBuilder.Entity<Relation>().HasKey(e => new { e.ProductId, e.OrderId });
            modelBuilder.Entity<Relation>().HasOne(e => e.Order).WithMany(x => x.Relations).HasForeignKey(x=>x.OrderId);
            modelBuilder.Entity<Relation>().HasOne(e => e.Product).WithMany(x => x.Relations).HasForeignKey(x => x.ProductId);

            //Установка свойств таблицы заказов
            modelBuilder.Entity<Order>().Property(x=>x.Created).HasDefaultValue(DateTime.UtcNow);
            modelBuilder.Entity<Order>().Property(x=>x.IsDeleted).HasDefaultValue(false);
            modelBuilder.Entity<Order>().Property(x=>x.Status).HasDefaultValue(1);

            //Установка свойств таблицы продуктов
            //modelBuilder.Entity<Product>().Property(x => x.IsDeleted).HasDefaultValue(false);

            //Установка свойств таблицы статусы
            modelBuilder.Entity<Status>().HasIndex(x => x.Name).HasDatabaseName("Statuses_Index_Name");
            //Заполнение начальными данными
            Guid guidProduct = Guid.NewGuid();
            Product product = new Product() { Id = guidProduct, Name = "RandomName" };
            modelBuilder.Entity<Product>().HasData(
                    product,
                    new Product() { Id = Guid.NewGuid(), Name = "RandomName1" },
                    new Product() { Id = Guid.NewGuid(), Name = "RandomName2" }
                );
            modelBuilder.Entity<Status>().HasData(
                    new Status { Id = 1, Name = "New", DisplayName = "Новый" },
                    new Status { Id = 2, Name = "AwaitingPayment", DisplayName = "Ожидает оплату" },
                    new Status { Id = 1, Name = "Paid", DisplayName = "Оплачен" },
                    new Status { Id = 1, Name = "SubmittedForDelivery", DisplayName = "Передан в доставку" },
                    new Status { Id = 1, Name = "Delivered", DisplayName = "Доставлен" },
                    new Status { Id = 1, Name = "Completed", DisplayName = "Завершён" }
                );
        }
    }
}